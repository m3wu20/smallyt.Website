# [hamster67.github.io/HamVal-Website](https://hamster67.github.io/HamVal-Website/)

HamVal Network 的新官網


## HamVal Network IP
- [主要 IP] mc.hamval.cloudns.be
- [備用 IP] hamval.owo.bar
