
# Keyboard Shortcuts

Files comes with built in keyboard shortcuts to make naviagting the app easier.

| Shortcut | Action |
| :---: | :---: |
| `Ctrl` + `C` | Copy |
| `Ctrl` + `X` | Cut |
| `Ctrl` + `V` | Paste |
| `Ctrl` + `T` | Create new tab |
| `Ctrl` + `W` | Close tab |
| `Ctrl` + `F4` | Close tab |
| `Ctrl` + `Shift` + `T` | Reopen recently closed tab |
| `Ctrl` + `Tab` | Switch tab |
| `Ctrl` + `N` | New window |
| `Ctrl` + `Shift` + `N` | New file |
